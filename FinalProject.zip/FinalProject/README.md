Submitted by: Rishi Anusuri (directory id: sanusuri)

Group Members: Rishi Anusuri

App Description: This is a loose recreation of the PC in the Pokemon games. ALlows the user to deposit, withdraw, release, and equip pokemon. Also allows users to view skills of equipped pokemon. 

YouTube Video Link: Pokemon Unite Pokemons,https://rapidapi.com/hefesto-technologies-hefesto-technologies-default/api/pokemon-unite-pokemons

APIs: VideoApp (http:notrealvideoapp.what), SoundApp (http:notreadlsoundapp.what)

Contact Email:  sanusuri@terpmail.umd.edu

Deployed App Link: https://notreal.what.terpNel/myApp